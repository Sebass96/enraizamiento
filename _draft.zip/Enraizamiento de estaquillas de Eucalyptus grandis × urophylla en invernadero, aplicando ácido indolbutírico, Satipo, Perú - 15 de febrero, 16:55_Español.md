**Mejorando la propagación clonal de *Eucalyptus grandis × urophylla* con ácido indol-3-butírico**

Sebastian Casas-Niño^1\*^; Gino Mondragón Aguirre^2^; Flavio Lozano-Isla^3^; José-Eloy Cuellar Bautista^1^.

*^1^ Centro de Investigación en Silvicultura y Mejoramiento Forestal, Facultad de Ciencias Forestales. Universidad Nacional Agraria La Molina.*

*^2^ Laboratorio de Silvicultura, Escuela Profesional de Ingeniería Forestal y Ambiental. Universidad Nacional de Jaén.*

*^3^ Facultad de Ingeniería y Ciencias Agrarias, Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas (UNTRM), Chachapoyas, Perú.*

* ^\*^ *Corresponding author: [20140231@lamolina.edu.pe](mailto:20140231@lamolina.edu.pe)

ORCID IDs:

Sebastian Casas-Niño: [0000-0002-6576-8761](https://orcid.org/0000-0002-6576-8761)

Gino Mondragón Aguirre: [0000-0002-4608-7928](https://orcid.org/0000-0002-4608-7928)

Flavio Lozano-Isla: [0000-0002-0714-669X](https://orcid.org/0000-0002-0714-669X)

José Eloy Cuellar Bautista: [0000-0001-5087-5719](https://orcid.org/0000-0001-5087-5719)





**Aspectos destacados**

* El ácido indol-3-butírico (AIB) mejora el enraizamiento de estaquillas de Eucalyptus urograndis en viveros de la selva central del Perú.
* El AIB favorece el desarrollo radicular en estaquillas de Eucalyptus urograndis durante el proceso de enraizamiento.
* La selección de una dosis óptima de AIB para la propagación de Eucalyptus urograndis maximiza la eficiencia del enraizamiento, evitando efectos de toxicidad o fallas en la formación de raíces.
* La propagación clonal de Eucalyptus urograndis mediante estaquillas enraizadas con AIB puede ser aplicada en programas de reforestación comercial.

**Declaraciones**

**Fondos**

La presente investigación no ha recibido financiamiento específico de agencias de los sectores público, comercial o sin fines de lucro.

**Conflicto de intereses**

Los autores declaran no tener conflictos de intereses.

**Contribución por autor**	

Conceptualización, S.C-N., G.M. and J-E.C.; metodología, S.C-N.; análisis formal, S.C-N. and F.L-I.; investigación, S.C-N.; curación de datos, S.C-N. and F.L-I.; escritura-preparación del borrador original, G.M., J-E.C., F.L-I. and S.C-N.; redacción-revisión y edición, F.L-I., G.M. and J-E.C.; visualización, S.C-N. Todos los autores han leído y aceptado la versión publicada del manuscrito.

**Agradecimientos**	

A la empresa TECFOREST y al Centro de Investigación en Silvicultura y Mejoramiento Forestal de la Facultad de Ciencias Forestales de la Universidad Nacional Agraria La Molina CESILMEF-FCF UNALM por el apoyo brindado.

**Disponibilidad de datos**

Las contribuciones originales presentadas en este estudio se incluyen en el artículo y material complementario. Los conjuntos de datos y análisis de datos reproducibles están disponibles en el archivo suplementario 1 y se puede acceder a ellos a través del repositorio de GitHub en: [https://github.com/Sebass96/enraizamiento](https://github.com/Sebass96/enraizamiento.git)	

**RESUMEN**

**Introducción:** El *Eucalyptus grandis × E. urophylla* es un híbrido que se caracteriza por su rápido crecimiento y alta productividad, lo que ha generado una creciente demanda para su propagación en viveros. Para preservar estas características, es necesario establecer jardines clonales y aplicar métodos de propagación clonal.

**Objetivo:** Evaluar la influencia del ácido indol-3-butírico (AIB) en el enraizamiento y desarrollo radicular de estaquillas de *Eucalyptus grandis × E. urophylla.*

**Materiales y métodos:** Se recolectaron estaquillas de un jardín clonal, las cuales fueron sometidas a cinco tratamientos enraizantes: T0 (control) con 0 ppm de ácido indol-3-butírico (AIB); T1 con 1000 ppm de AIB; T2 con 1500 ppm de AIB; T3 con 2000 ppm de AIB; y T4, un preparado comercial con 4000 ppm de ácido naftalenacético (ANA) y 1000 ppm de AIB. El experimento se realizó bajo un diseño completamente al azar (DCA) con 90 repeticiones. Tras la aplicación de los tratamientos, las estaquillas se instalaron en un invernadero por un periodo de 30 días. Al finalizar este periodo se determinó el porcentaje de enraizamiento y mortalidad; número, longitud y peso seco de las raíces desarrolladas.

**Resultados y discusión:** Los tratamientos T2 y T4 presentaron la mejor respuesta para el enraizamiento y desarrollo radicular. Asimismo, luego de comparar con otros estudios, se determinó que concentraciones muy altas de AIB pueden generar efectos tóxicos en las estaquillas.

**Conclusión:** El AIB tiene un impacto positivo en el proceso de rizogénesis de estaquillas de *Eucalyptus grandis × E. urophylla*.



**Palabras clave:** Clonación; desarrollo radicular; enraizadores; esquejes; propagación asexual; rizogénesis; vivero forestal.

**Keywords:** asexual propagation; cloning; cuttings; forest nursery; rhizogenesis; rooting agents; root development.



# **INTRODUCCIÓN**

De acuerdo al Informe de los Recursos Forestales Mundiales 2020 [(FAO, 2021)](https://www.zotero.org/google-docs/?ibPAxG), a nivel mundial existen 131 millones de hectáreas de PFC, que representan el 3% del área de bosque mundial. Aunque la superficie de Plantaciones Forestales Comerciales (PFC) se incrementó entre 2010 y 2020, la tasa media anual de aumento, de 1.48 millones de hectáreas por año, fue inferior a la registrada en décadas anteriores. En el continente americano, los resultados son diferenciados. América del Norte, Centroamérica y el Caribe cuentan con 15 177 de miles de ha de PFC, mientras que América del Sur posee 20 099 de miles de hectáreas. Al igual que la tendencia mundial, la tasa media anual de aumento de la superficie de PFC en América disminuyó en el decenio 2010-2020, en particular debido a la influencia de Estados Unidos, en América del Norte, y Brasil, en América del Sur. En esta región también influyeron países como Chile, Colombia, Perú y Uruguay.

En el Perú, la Ley Forestal y de Fauna Silvestre N° 29763 define a las plantaciones forestales como ecosistemas generados por la intervención humana, en los cuales se establecen una o más especies forestales, tanto nativas como introducidas, con el objetivo de obtener Productos Forestales Maderables (PFM), Productos Forestales No Maderables (PFNM) o proveer servicios ecosistémicos; o una combinación de estos [(Servicio Nacional Forestal y de Fauna Silvestre, 2015)](https://www.zotero.org/google-docs/?xVic1j). Las PFC, además de proveer materias primas y bienes; contribuyen a reducir la presión sobre el aprovechamiento forestal maderable en bosques naturales [(Pirard et al., 2016)](https://www.zotero.org/google-docs/?jtDYR6), mitigar los efectos del cambio climático por el potencial de captura y almacenamiento de carbono de los árboles plantados [(Osuri et al., 2020)](https://www.zotero.org/google-docs/?6lwB66), ofrecer servicios ecosistémicos de provisión y soporte [(Zeng et al., 2021)](https://www.zotero.org/google-docs/?zCR3dp) y posibilitar la conservación de la biodiversidad [(Silva et al., 2019)](https://www.zotero.org/google-docs/?E33P1p).

Según el Informe de la Evaluación de los Recursos Forestales Mundiales 2020, Perú [(FAO, 2021)](https://www.zotero.org/google-docs/?DWy8xQ), el país posee 1 088 470 hectáreas de PFC. Sin embargo, estos datos pueden no ser completamente precisos, ya que la superficie plantada se estima en función del número de plántulas sembradas o que salieron de viveros. Además, los datos no permiten diferenciar con claridad entre plantaciones forestales ubicadas en tierras estatales, comunales o privadas [(Guariguata et al., 2017)](https://www.zotero.org/google-docs/?oRVbpy). A pesar de los avances obtenidos, la productividad de las PFC en el Perú sigue siendo baja, como resultado del manejo silvicultural deficiente, casi nula incorporación de mejoramiento genético, la aplicación limitada de técnicas de mejoramiento de suelos y la falta de criterios para la selección de sitios de plantación [(Guariguata et al., 2017)](https://www.zotero.org/google-docs/?lv1MaP).

Para promover el desarrollo de PFC en el Perú, resulta fundamental la implementación de una política forestal integral y articulada. Como primer paso, se debe identificar y establecer corredores económicos estratégicos para la industria forestal, donde se concentre el establecimiento de PFC. También es necesario promover el saneamiento de tierras públicas para complementar las iniciativas privadas de establecimiento de PFC. Además, los programas de plantación deben incluir tanto especies nativas como introducidas; sin embargo, no se puede dejar de considerar que la demanda del mercado determina la selección de especies a establecer [(Servicio Nacional Forestal y Fauna Silvestre, 2021)](https://www.zotero.org/google-docs/?VC7ZsU). Asimismo, el desarrollo tecnológico, la investigación y la innovación son herramientas fundamentales que se requieren desarrollar para potenciar el crecimiento y sostenibilidad de las PFC.

Para enfrentar estos desafíos, se han implementado diferentes acciones. Un ejemplo es la introducción en el ~~a~~ Perú del híbrido *Eucalyptus grandis × E. urophylla* en proyectos de PFC en las regiones amazónicas de los departamentos de Ucayali, Huánuco, Junín, Pasco y San Martín  [(Servicio Nacional Forestal y Fauna Silvestre, 2021)](https://www.zotero.org/google-docs/?oQg7aN). Este híbrido es ampliamente utilizado en viveros tecnificados que emplean clones de la especie como material propagativo debido a su rápido crecimiento y alta productividad. Otra medida destacada ha sido la aplicación de la propagación vegetativa, una técnica eficiente para mantener la calidad genética en periodos relativamente cortos. Esta estrategia reduce la dependencia de semillas botánicas de origen desconocido y permite ofrecer clones, como estaquillas, durante todo el año [(Cachique et al., 2011)](https://www.zotero.org/google-docs/?98h7OB). 

La implementación de técnicas de propagación vegetativa desempeña un papel crucial en el mejoramiento genético forestal y en el incremento de la productividad de PFC en la región amazónica del Perú. Estas técnicas permiten conservar las características genéticas mejoradas en las plantaciones establecidas con plantones propagados asexualmente. El aumento de la productividad se debe a factores, como la uniformidad de las características físicas y mecánicas de la madera, la obtención de fustes de formas deseables, una mayor resistencia a enfermedades, plagas y condiciones ambientales extremas, el incremento de las tasas anuales de crecimiento y la facilidad del manejo forestal [(Abedini, 2005](https://www.zotero.org/google-docs/?1uVIwL); [Navarrete-Luna & Vargas-Hernández, 2005)](https://www.zotero.org/google-docs/?xcEnCs)

A pesar del alto potencial que ofrecen estas técnicas, la propagación asexual de especies comerciales ha sido poco explorada en el Perú, especialmente en el caso del híbrido *E. grandis × E. urophylla*. Para fomentar el establecimiento de PFC sostenibles en términos ambientales y económicos, que contribuyan a mejorar la calidad de vida de las comunidades amazónicas, se propuso investigar el efecto del ácido indol-3-butírico (AIB) sobre el enraizamiento y el desarrollo radicular de estaquillas de *Eucalyptus grandis × E. urophylla*. El objetivo fue determinar la dosis óptima de AIB que viabilice su propagación comercial, contribuyendo al desarrollo sostenible del sector forestal en la región.



# **MATERIALES Y MÉTODOS**

## **Área de estudio**

El presente estudio se realizó en el invernadero de la compañía TEC FOREST S.A.C., ubicado en el distrito de San Martín de Pangoa, provincia de Satipo, región Junín, Perú. Se localiza en las coordenadas 11° 25' 24.72" S,  74° 29' 17.20" o (-11.42353 S, -74.4881 O); a una altitud de 792 m s. n. m. ([Figure 1](?tab=t.0#bookmark=id.u031vacyq5va)). La temperatura media de la zona varía entre los 19 °C y los 35 °C. El régimen de precipitaciones es estacional, con una temporada lluviosa de octubre a abril y una época seca de mayo a septiembre [(Servicio Nacional de Meteorología e Hidrología del Perú, 2024)](https://www.zotero.org/google-docs/?JHqz3B). En el interior del invernadero se registraron temperaturas entre 25 °C a 30 °C y la humedad relativa varió del 60 % al 70 %.

![Ubicación geográfica del área de investigación experimental. Vivero forestal de la empresa TECFOREST, distrito de San Martín de Pangoa, departamento de Junín, Selva Central del Perú.](img_0.jpg){#fig:id.u031vacyq5va}

## 







## **Material vegetal** 

Las estaquillas utilizadas en el presente estudio fueron obtenidas de plantas madre del clon *E. grandis × E. urophylla*, identificado con el código TF-001. Estas plantas madre tenían siete meses de edad, una altura promedio de 1.80 m y un diámetro a la altura del pecho (DAP) promedio de 10 cm. El material vegetal de este clon fue importado desde Brasil como parte de un lote compuesto por ocho clones, seleccionados mediante un programa de innovación tecnológica en plantaciones forestales.

Inicialmente, estos clones fueron establecidos en una parcela de investigación clonal en Oxapampa, dentro de un proyecto orientado a evaluar la adaptación y el crecimiento de clones en condiciones del Perú. En dicha parcela se realizaron procesos de propagación sucesiva para garantizar la disponibilidad de material vegetativo de calidad. A partir de este material, se implementaron parcelas experimentales en diversos sitios de la selva central, abarcando un gradiente altitudinal que va desde los 300 m.s.n.m. en Iscozacín (Pichis Palcazú) hasta los 3 000 m.s.n.m. en Palca, Tarma. 

La producción de los clones se gestionó en el jardín clonal de la empresa TEC FOREST S.A.C., utilizando material vegetal proveniente del distrito de Palca, provincia de Tarma, departamento de Junín [(Machacuay & Llancari, 2020)](https://www.zotero.org/google-docs/?rMvsuq).

## **Fase experimental**

El experimento inició con la fertilización del jardín clonal de la empresa TECFOREST con una fórmula 20%N – 20%P – 20%K durante el mes de enero de 2021. Este proceso tuvo como objetivo estimular el desarrollo de nuevos brotes del clon TF-001 y así favorecer el enraizamiento de las estaquillas a colectar. Dos semanas después, se procedió a la recolección de las estaquillas apicales utilizando tijeras de podar desinfectadas. Se realizó un corte limpio en bisel por debajo de un nudo o yema, evitando rajaduras. Inmediatamente después, las estaquillas se colocaron en un recipiente con agua para conservar su turgencia y transportarlas a las instalaciones de la empresa. 

En el vivero, se cortó el 50% de la lámina foliar de las hojas basales y se desinfectaron las estaquillas sumergiéndolas en una solución fungicida al 0.1% durante 10 segundos [(Swarts et al., 2018)](https://www.zotero.org/google-docs/?ToUfZz). Para la aplicación de los tratamientos evaluados, se prepararon soluciones enraizantes con las siguientes composiciones: T0 (control) con 0 ppm de ácido indol-3-butírico (AIB); T1 con 1000 ppm de AIB; T2 con 1500 ppm de AIB; T3 con 2000 ppm de AIB; y T4, un preparado comercial con 4000 ppm de ácido naftalenacético (ANA) y 1000 ppm de AIB. 

Para los tratamientos T1, T2 y T3, el AIB se disolvió en agua destilada, y las bases de las estaquillas se sumergieron en la solución durante 60 segundos, evitando el contacto de la parte aérea con el enraizante. En el caso de T4, se aplicó una mezcla en polvo de ANA y AIB directamente en las bases de las estaquillas, eliminando cuidadosamente el exceso de polvo antes de insertarlas en el sustrato.

Antes del estaquillado, los tubetes T-51 (2.8 cm de diámetro superior, 1.0 cm de diámetro inferior, 12.5 cm de altura y 51 cm³ de volumen) fueron llenados con un sustrato compuesto por cáscara de pino compostada y vermiculita expandida. Posteriormente, el sustrato fue humedecido hasta alcanzar su capacidad de campo. Durante el establecimiento de las estaquillas, la base de cada una se insertó  a una profundidad de 2 cm en el sustrato húmedo, compactándolo manualmente alrededor para eliminar bolsas de aire y garantizar un adecuado contacto entre la base de las estaquillas y el sustrato, promoviendo un óptimo prendimiento. Finalmente, los tubetes fueron colocados en bandejas y dispuestos dentro del invernadero.

## **Variables de estudio**

Después de 30 días de establecer las estaquillas, se evaluaron el enraizamiento (%), la mortandad (%), el número de raíces (unidad), peso seco de raíces (mg) y la longitud de la raíz más larga (cm). El enraizamiento se evaluó en función del cálculo de la proporción de estaquillas enraizadas, con presencia de callosidad y muertas respecto al total establecido en cada tratamiento. Para analizar el desarrollo radicular, se registró el número total de raíces emergidas por estaquilla enraizada, se midió la longitud de la raíz más larga por estaquilla enraizada con una regla milimétrica y se determinó el peso seco de las raíces. Este último se obtuvo tras secar las raíces en una estufa a 70 °C hasta alcanzar peso constante, y luego se pesaron utilizando una balanza analítica. 

Los datos recopilados permitieron calcular los porcentajes de enraizamiento, presencia de callo y mortalidad, además de describir cuantitativamente el desarrollo del sistema radicular bajo las condiciones de cada tratamiento.

## **Diseño experimental y análisis estadístico**

El experimento se desarrolló bajo un diseño completamente al azar (DCA), donde cada unidad experimental correspondió  a una estaquilla de *E. grandis × E. urophylla*, con un total de 90 estaquillas por tratamiento. Los tratamientos evaluados fueron las diferentes dosis de AIB, descritas previamente. 

Las variables relacionadas con el enraizamiento fueron analizadas mediante estadística descriptiva para caracterizar su comportamiento general. Para las variables asociadas al desarrollo radicular, se emplearon modelos lineales de efectos mixtos, los cuales ofrecen mayor robustez frente a posibles violaciones de los supuestos de normalidad y homocedasticidad [(Schielzeth et al., 2020)](https://www.zotero.org/google-docs/?qQNQE7). Posteriormente, se realizó un análisis de varianza (ANOVA) sobre dichos modelos con el fin de identificar diferencias significativas entre tratamientos.

El análisis estadístico se realizó utilizando el paquete stats de R. Para la comparación de medias, se aplicó el método de diferencia mínima significativa (LSD) de Fisher con un nivel de significancia de α = 0.05, empleando el paquete agricolae [(Mendiburu, 2023)](https://www.zotero.org/google-docs/?m2waDw). Adicionalmente, se llevó a cabo un análisis multivariado mediante análisis de componentes principales (PCA) con el paquete FactoMineR, con el objetivo de explorar la estructura de las variables y su relación con los tratamientos [(Husson et al., 2024)](https://www.zotero.org/google-docs/?qt9F4y). 

Todo el procesamiento estadístico se realizó en el software R versión 4.4.2. [(R Core Team, 2024)](https://www.zotero.org/google-docs/?SwAISW).





# **RESULTADOS**

## **Enraizamiento**

Para evaluar la influencia del ácido indol-3-butírico (AIB) en el enraizamiento de estaquillas de *E. grandis × E. urophylla*, se analizaron las proporciones de estaquillas con formación de callo, enraizadas y muertas. Estas variables son fundamentales para determinar la efectividad del AIB en el proceso de rizogénesis durante la propagación vegetativa. 

Se realizó un análisis univariado descriptivo para identificar diferencias entre los tratamientos aplicados, a fin de comparar cuantitativamente la eficiencia del uso de esta hormona en la inducción del sistema radicular ([Figure 2](?tab=t.0#bookmark=id.icu4u475za3w)).



![Estado de las estaquillas de *E. grandis × E. urophylla* en respuesta a la aplicación de diferentes dosis de ácido indol-3-butírico (AIB) al final del periodo de enraizamiento.](img_1.jpg){#fig:id.icu4u475za3w}

Se observaron diferencias significativas en la variable rooted cuttings,  entre el tratamiento control y aquellos en los que se aplicaron enraizantes. El tratamiento comercial (4000 ppm ANA + 1000 ppm AIB) presentó el mayor porcentaje de enraizamiento con 69%, seguido del tratamiento con 1500 ppm de AIB, que alcanzó 44%. Ambos superaron significativamente al control, que registró solo un 7% de enraizamiento. Además, entre los tratamientos con AIB, el de 1500 ppm destacó con un porcentaje de enraizamiento superior al de 1000 ppm y 2000 ppm, los cuales presentaron 19 % y 29%, respectivamente.

En la variable callused cuttings, se observaron diferencias significativas entre el tratamiento control (sin aplicación de hormona enraizante) y los tratamientos con diferentes dosis de AIB. El tratamiento control (0 ppm AIB) presentó el menor porcentaje de estaquillas con presencia de callo (14%), en contraste con los tratamientos con AIB, que alcanzaron un promedio del 30%.

En cuanto a la mortalidad, se observó una tendencia opuesta a las variables anteriores. El tratamiento control (sin aplicación de hormona enraizante) presentó el mayor porcentaje de mortalidad, alcanzando 79%. Por otro lado, los menores valores de mortalidad corresponden al tratamiento comercial (4000 ppm ANA + 1000 ppm AIB) con un 7%, seguido del tratamiento con 1500 ppm de AIB, que obtuvo 21%. Dentro de los tratamientos con AIB, el de 1500 ppm presentó la menor mortalidad, seguido por los tratamientos de 2000 ppm con 41% y 1000 ppm con 51%. Estos resultados destacan al tratamiento comercial como el más efectivo para incrementar el enraizamiento y, en consecuencia, reducir la mortalidad, seguido por el tratamiento con 1500 ppm de AIB.

## **Desarrollo radicular**

Para determinar la dosis óptima de ácido indol-3-butírico (AIB) que maximice el desarrollo radicular y mejore la eficiencia en la propagación vegetativa de *E. grandis × E. urophylla*, se evaluó el efecto de este regulador de crecimiento sobre las características del sistema radicular. Las variables analizadas incluyeron el número total de raíces, la longitud de la raíz más larga y el peso seco de las raíces. Los datos obtenidos fueron sometidos a un análisis univariado mediante ANOVA (p < 0.05) para identificar diferencias significativas entre las diferentes dosis de AIB aplicadas.




| **Tratamientos**        | **Media**               | **Desviación estándar** | **Mínimo**              | **Máximo**              | **Significancia**        |
|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|--------------------------|
| T0                      | 1.833                   | 0.753                   | 1                       | 3                       | a                        |
| T1                      | 2.176                   | 1.131                   | 1                       | 4                       | a                        |
| T2                      | 2.200                   | 1.244                   | 1                       | 6                       | a                        |
| T3                      | 2.192                   | 1.167                   | 1                       | 5                       | a                        |
| T4                      | 2.274                   | 1.089                   | 1                       | 5                       | a                        |




: Resultados de la prueba de diferencia mínima significativa (LSD) de Fisher para la dosis de ácido indol-3-butírico (AIB) según la variable número de raíces. Grupos según probabilidad de diferencia de medias (α = 0.05). Los tratamientos con la misma letra no son significativamente diferentes (p-value < 0.05, n = 151). {#tbl:id.qlqbpsrco9wo}

El análisis estadístico del número de raíces, realizado mediante ANOVA (α = 0.05), no evidenció diferencias significativas entre los tratamientos (p = 0.92). Sin embargo, se observaron tendencias que sugieren un mayor desarrollo radicular en los tratamientos con aplicación de AIB, con valores de hasta seis raíces por estaquilla, en comparación con el tratamiento control (0 ppm AIB), que mostró un máximo de tres raíces desarrolladas. Entre los tratamientos evaluados, el preparado comercial (4000 ppm ANA + 1000 ppm AIB) registró la mayor media, con 2.27 raíces desarrolladas por estaquilla, mientras que el tratamiento control presentó la media más baja, con 1.83 raíces. Estos resultados sugieren un efecto potencialmente positivo de la combinación hormonal de ANA y AIB en la promoción del desarrollo radicular, aunque sin diferencias estadísticamente significativas en este caso. ([Table 1](?tab=t.0#bookmark=id.qlqbpsrco9wo)).



![Desarrollo radicular de estaquillas de *E. grandis × E. urophylla* por cada dosis aplicada de ácido indol-3-butírico (AIB). (a) Longitud de raíces (cm) desarrolladas al final del proceso de rizogénesis. (b) Peso seco de raíces (mg) desarrolladas al final del proceso de rizogénesis. Resultados de la  prueba de diferencia mínima significativa (LSD) de Fisher. Grupos según probabilidad de diferencia de medias (α = 0.05). Los tratamientos con la misma letra no son significativamente diferentes (p-value < 0.05, n = 151).](img_2.jpg){#fig:id.6ze9vl8bgddo}

El análisis estadístico de la longitud de raíces, realizado mediante ANOVA (con un nivel de significancia de α = 0.05), mostró diferencias significativas entre los tratamientos (p = 0.11). Los resultados indicaron que el tratamiento control (0 ppm de AIB) y el tratamiento con 1 000 ppm de AIB presentaron las medias más bajas en longitud de raíces, con valores de 3.43 cm y 4.10 cm, respectivamente. En contraste, el tratamiento comercial (4 000 ppm ANA + 1 000 ppm AIB) registró la mayor media, alcanzando 6.92 cm. Además, mientras que el tratamiento control mostró un valor máximo de 5.00 cm, los tratamientos con aplicación de hormonas alcanzaron hasta 19.00 cm. No obstante, la mayoría de las raíces observadas en este estudio presentaron longitudes entre 1.00 cm y 10.00 cm, lo que sugiere una tendencia general hacia el desarrollo de raíces cortas bajo las condiciones experimentales.

Por otro lado, el análisis del peso seco de las raíces, también realizado mediante ANOVA (α = 0.05), mostró diferencias altamente significativas entre los tratamientos (p = 0.001). Los tratamientos control (0 ppm AIB), 1 000 ppm AIB y 2 000 ppm AIB presentaron los valores más bajos de peso seco, con medias de 7.36 mg, 7.10 mg y 7.98 mg, respectivamente. En contraste, el tratamiento con 1 500 ppm de AIB y el preparado comercial (4 000 ppm ANA + 1 000 ppm AIB) destacaron con medias de 12.12 mg y 13.98 mg, respectivamente, demostrando un efecto positivo de estas dosis en el desarrollo del sistema radicular.

Para analizar la asociación general de las variables e individuos, se realizó un análisis multivariado de componentes principales (PCA) ([Figure 4](?tab=t.0#bookmark=id.lown5jg4j2wr)).

![Análisis de Componentes Principales (PCA) de las variables de desarrollo radicular basado en el uso de diferentes dosis de ácido indol-3-butírico (AIB). (a) Se evaluaron variables para determinar el efecto del regulador de crecimiento sobre las características del sistema radicular. (b) Se utilizaron tratamientos basados ​​en concentraciones de AIB para determinar la dosis óptima que maximice el desarrollo radicular. El análisis se basó en 151 observaciones (n = 151).](img_3.jpg){#fig:id.lown5jg4j2wr}



Para evaluar la interacción entre las variables, se aplicó un análisis de componentes principales (PCA). Los dos primeros componentes explicaron el 96.13% de la varianza acumulada, con la Dimensión 1 explicando el 82.01% y la Dimensión 2 el 14.12% de la varianza ([Figure 4](?tab=t.0#bookmark=id.lown5jg4j2wr)a). En la Dimensión 1, la longitud de raíces fue la variable con mayor contribución (37.70%), seguida del número de raíces (31.41%) y el peso seco de raíces (30.89%). En la Dimensión 2, el peso seco de raíces y el número de raíces contribuyeron predominantemente, con contribuciones de 51.95% y 48.01%, respectivamente, mientras que la longitud de raíces tuvo una contribución marginal de 0.04%.

Los vectores del PCA indican la dirección y fuerza de las relaciones entre las variables, evidenciando una correlación positiva fuerte entre el número, la longitud y el peso seco de raíces. Destaca que la longitud de raíces mostró una correlación positiva alta con la Dimensión 1 (0.96). En contraste, en la Dimensión 2, el número de raíces presentó una correlación negativa moderada (-0.45) ([Figure 4](?tab=t.0#bookmark=id.lown5jg4j2wr)a).

En términos de tratamientos, se observó que las concentraciones de 4 000 ppm ANA + 1 000 ppm AIB y 1 500 ppm AIB estuvieron alineadas con los vectores de longitud y peso seco de raíces, lo que indica que estas dosis favorecieron de manera efectiva estas características. En cuanto al número de raíces, las estaquillas tratadas con 2 000 ppm AIB registraron los valores más altos. Por el contrario, las concentraciones de 0 ppm AIB (control) y 1 000 ppm AIB mostraron una asociación negativa con las variables de desarrollo radicular, lo que sugiere que estas dosis resultaron en los valores más bajos de número, longitud y peso seco de raíces durante el proceso de rizogénesis en estaquillas de *E. grandis × E. urophylla*  ([Figure 4](?tab=t.0#bookmark=id.lown5jg4j2wr)b).

# 

# **DISCUSIONES**

En las últimas cuatro décadas, el Perú ha experimentado un crecimiento significativo en el sector forestal, impulsado por la expansión de plantaciones comerciales de especies exóticas [(Canchari et al., 2018)](https://www.zotero.org/google-docs/?3ku9Bg). El departamento de Junín destaca por su potencial, con 15 000 hectáreas aptas para este propósito. Entre las especies introducidas y cultivadas en la región, el pino (*Pinus sp.*) y el eucalipto (*Eucalyptus sp.*) son altamente demandados en los mercados nacional e internacional por la calidad de su madera [(Gorbitz et al., 2020)](https://www.zotero.org/google-docs/?b8a39n). Para el establecimiento de plantaciones con estas especies, la propagación vegetativa surge como una herramienta clave para preservar la calidad genética y asegurar un suministro constante de material propagativo de alta calidad durante a lo largo del año [(Cachique et al., 2011)](https://www.zotero.org/google-docs/?cGLeMc). A pesar de la existencia de diversos estudios en *E. grandis × E. urophylla*, el conocimiento sobre la propagación clonal mediante estaquillas y el uso óptimo de ácido indol-3-butírico (AIB) sigue siendo limitado en Perú. Esta investigación evaluó el efecto del AIB sobre el enraizamiento y el desarrollo radicular de estaquillas de *E. grandis × E. urophylla*, con el objetivo de determinar la concentración óptima de AIB para la propagación comercial de esta especie en la Selva Central del Perú.

En cuanto al enraizamiento, de las diferencias encontradas entre el tratamiento comercial (4 000 ppm ANA + 1 000 ppm AIB) y los demás tratamientos, se sabe que a pesar de que el ANA es ligeramente más tóxico que el AIB, presenta características similares. No obstante, la combinación ANA + AIB resulta más efectiva que su aplicación por separado, promoviendo un mayor enraizamiento y una mayor producción radicular [(Peña-Baracaldo et al., 2018)](https://www.zotero.org/google-docs/?voewVv). Por otro lado, las diferencias entre el tratamiento con 1 500 ppm AIB y los tratamientos con 1 000 ppm y 2 000 ppm AIB concuerdan con los resultados obtenidos por [Carranza Patiño et al., (2022)](https://www.zotero.org/google-docs/?UiwJEo). En su estudio con *E. grandis × E. urophylla*, se obtuvieron porcentajes de enraizamiento más altos con la aplicación de 1 500 ppm AIB, lo que sugiere que esta concentración podría favorecer significativamente la propagación vegetativa de la especie, destacándose como una dosis óptima para este propósito.

El enraizamiento en las estacas aumenta proporcionalmente con la concentración del enraizante hasta alcanzar un punto óptimo, tras el cual dosis mayores provocan toxicidad y reducen la capacidad de enraizamiento [(Nourissier & Monteuuis, 2008)](https://www.zotero.org/google-docs/?BtXIJe). Este fenómeno ocurre porque el efecto estimulante de las auxinas disminuye a concentraciones más altas, lo que inhibe el proceso de enraizamiento debido a la síntesis de etileno inducida por niveles elevados de auxina. Además, concentraciones mínimas de hormonas pueden favorecer únicamente la formación de callos, sin llegar a desarrollar raíces [(Alcantara-Cortes et al., 2019)](https://www.zotero.org/google-docs/?wanayD). En este contexto, las diferencias observadas podrían atribuirse a que una concentración de 1 000 ppm de auxina no es suficiente para estimular el enraizamiento, mientras que a 2 000 ppm se genera un efecto tóxico que inhibe el proceso, reafirmando la importancia de identificar una dosis óptima para maximizar la eficiencia del enraizamiento. Estos porcentajes de enraizamiento son similares a los reportados por [Brondani et al., (2010)](https://www.zotero.org/google-docs/?OriJRU);  [Nourissier & Monteuuis (2008)](https://www.zotero.org/google-docs/?azzfMd) y [Ayala et al., (2020)](https://www.zotero.org/google-docs/?BwxQ5I), quienes registraron bajos porcentajes en el enraizamiento de *E. benthamii × E. dunnii*; *E. grandis × E. urophylla*; *E. grandis × E. tereticornis y E. grandis × E. camaldulensis*, respectivamente. Estos autores destacan que los porcentajes de enraizamiento varían según el material genético de los clones empleados, observándose gran variación en la capacidad de enraizar y/o sobrevivir, la cual está asociada al genotipo de los clones utilizados. Por lo tanto, se presume que este factor podría explicar los bajos niveles de enraizamiento observados en el presente estudio.

Los resultados del porcentaje de enraizamiento fueron menores en comparación con lo reportado por [Titon et al., (2003)](https://www.zotero.org/google-docs/?l5S2EC) y [Bueno et al., (2008)](https://www.zotero.org/google-docs/?Pw2hyq) en sus experimentos con miniestacas de *E.  grandis* y *E. grandis × E.  urophylla*, respectivamente. Las posibles explicaciones se encuentran en la técnica del mini estaquillado, a partir de plantas madre propagadas mediante estacas y su nutrición se puede controlar de manera más efectiva. El estado nutricional de la planta donante influye significativamente en la formación de raíces, ya que la concentración de auxinas y carbohidratos impacta directamente el proceso de enraizamiento [(Oliva-Cruz et al., 2005](https://www.zotero.org/google-docs/?sJmleL); [Bautista-Ojeda et al., 2022)](https://www.zotero.org/google-docs/?wxhKLP).  Este hallazgo es consistente con lo reportado por [Gallo et al., (2017)](https://www.zotero.org/google-docs/?ADMuX0), quienes trabajaron con clones de *E. grandis × E. urophylla* y *E. urophylla × E. globulus*. En su estudio concluyeron que el contenido interno de auxinas en los brotes tiene un impacto directo en la rizogénesis, lo que subraya la importancia de un manejo adecuado del material genético y las condiciones de las plantas madre.

En cuanto a la mortalidad de las estaquillas, los resultados indicaron que el uso de AIB en concentraciones adecuadas reduce significativamente la mortalidad. Esto concuerda con los hallazgos de [Bautista-Ojeda et al., (2022)](https://www.zotero.org/google-docs/?fcMhxg) y [Carranza Patiño et al., (2022)](https://www.zotero.org/google-docs/?x6398I), quienes demostraron que la aplicación de auxinas en dosis óptimas favorece la supervivencia de las estaquillas durante el proceso de rizogénesis. Los niveles de mortalidad observados en este estudio son similares a los reportados por [Brondani et al., (2010)](https://www.zotero.org/google-docs/?OsCUh5) y [Rivera Melo et al., (2021)](https://www.zotero.org/google-docs/?HVFp5w). En sus investigaciones, utilizando diferentes concentraciones de AIB para inducir el enraizamiento en híbridos de *Eucalyptus benthamii × E. dunnii* y *Pinus hartwegii*, respectivamente, registraron un aumento en la mortalidad a medida que se incrementa la concentración de la hormona. Esto refuerza la hipótesis de que concentraciones excesivas de AIB pueden provocar fitotoxicidad, afectando negativamente la viabilidad de las estaquillas.

Los niveles de mortalidad observados en este estudio para los tratamientos con diferentes dosis de AIB difieren ligeramente de los reportados por [Muñoz, (2018)](https://www.zotero.org/google-docs/?usvdzm), quien registró tasas de mortalidad del entre 20% y 30% en estaquillas de *Eucalyptus grandis × E. urophylla*. El menor porcentaje de mortalidad reportado por Muñoz podría atribuirse al uso de la técnica de miniestaquillado, la cual ~~~~favorece el enraizamiento al proporcionar condiciones de crecimiento más controladas. Estas, al desarrollar un sistema radicular más eficiente, presentan una mayor capacidad para absorber agua y nutrientes, lo que mejora su supervivencia. Por otro lado, [Felice et al., (2024)](https://www.zotero.org/google-docs/?TrQzoy) no encontraron un impacto significativo en la mortalidad de miniestaquillas apicales de *E. camaldulensis* frente a distintas concentraciones de AIB. Estos autores sugieren que factores como el grado de madurez del material vegetal, la variabilidad genética de los clones y las condiciones ambientales desempeñan un papel crucial en la respuesta al enraizamiento y, por ende, en la supervivencia de las estaquillas.

En relación con el número de raíces, se observaron diferencias entre los tratamientos con AIB y el control (0 ppm AIB). Estas diferencias podrían explicarse por la tendencia observada en diversas especies, en las cuales un incremento en la dosis de AIB suele aumentar la cantidad promedio de raíces formadas por estaquilla [(Vásquez Inuma et al., 2018)](https://www.zotero.org/google-docs/?ptUr5n). Este efecto puede atribuirse a la acción del AIB, que favorece la redistribución de compuestos desde las hojas y tallos hacia la base de la estaquilla, favoreciendo la rizogénesis. Los carbohidratos, al desempeñar un papel clave en la formación de raíces, podrían contribuir a este aumento, ya que estimulan el desarrollo radicular [(Alcantara-Cortes et al., 2019)](https://www.zotero.org/google-docs/?j3DyPw). Los resultados obtenidos en este estudio sugieren que las variaciones en el número de raíces están directamente influenciadas por la aplicación de AIB, lo cual concuerda con los hallazgos de [Lopes et al., (2019)](https://www.zotero.org/google-docs/?Xcrwrw), quienes señalan que este regulador de crecimiento estimula significativamente la formación de raíces en miniestacas de *E. urophylla*.

El análisis estadístico no mostró diferencias significativas entre los tratamientos evaluados. Resultados similares fueron reportados por [Borges et al., (2011)](https://www.zotero.org/google-docs/?k0aWQz) en su estudio con miniestacas de clones de *E. urophylla ×E.  globulus* y *E. grandis × E. globulus*. Sin embargo, estos hallazgos contrastan con los de [Basauri Torres et al., (2019)](https://www.zotero.org/google-docs/?Y81ImL), quienes demostraron en su experimento con miniestacas de *Guazuma crinita* que la aplicación en polvo de AIB influye positivamente en la cantidad de raíces formadas. Estos resultados sugieren que, en ciertas especies y clones, el AIB podría tener un efecto variable, posiblemente asociado a su capacidad para movilizar compuestos hacia la base de las estaquillas y favorecer la rizogénesis. No obstante, en el presente estudio, no se encontraron diferencias estadísticamente significativas en el número de raíces entre los tratamientos con AIB, lo que indica que su efecto puede depender de factores específicos como el genotipo y las condiciones experimentales.

Los valores de longitud de raíces obtenidos en este estudio son similares a los reportados por  [Muñoz (2018)](https://www.zotero.org/google-docs/?9APN0e) y [Carranza Patiño et al. (2022)](https://www.zotero.org/google-docs/?BA6Mfd), quienes informaron promedios de 8.10 cm y 9.60 cm, respectivamente, en *E. grandis × E. urophylla*. Sin embargo, ambos autores no encontraron diferencias estadísticas significativas entre las diferentes dosis de AIB aplicadas. En contraste, los resultados del presente estudio muestran que, aunque no hubo diferencias significativas entre los tratamientos con distintas concentraciones de AIB, sí se encontraron diferencias significativas entre el tratamiento testigo (0 ppm AIB) y 1000 ppm AIB respecto al tratamiento comercial (4 000 ppm ANA + 1 000 ppm AIB), siendo este último el que alcanzó la mayor media de longitud de raíces.

Esta variación podría estar asociada a factores como los señalados por [De Almeida et al. (2017)](https://www.zotero.org/google-docs/?5ozHfC), [Vilasboa et al. (2019)](https://www.zotero.org/google-docs/?3SGKBB) y [More et al. (2021)](https://www.zotero.org/google-docs/?G5QGss), quienes destacaron que condiciones como la irradiación, temperatura y disponibilidad de nitrógeno pueden influir en la actividad, transporte y eficacia de las auxinas, además de su interacción con los carbohidratos. Estos factores, combinados con la acción sinérgica del ANA y el AIB, podrían explicar las diferencias entre los resultados obtenidos por los autores y los presentados en  este estudio. Se presume que la interacción entre las condiciones ambientales, la nutrición de las plantas madre y la aplicación de reguladores de crecimiento fue determinante para el incremento en la longitud de raíces de *E. grandis × E. urophylla*.

En cuanto al peso seco de raíces, se observaron diferencias estadísticamente significativas entre los tratamientos control (0 ppm AIB), 1 000 ppm AIB y 2 000 ppm AIB en comparación con los tratamientos de 1 500 ppm AIB y el preparado comercial (4 000 ppm ANA + 1 000 ppm AIB). Estos resultados coinciden con los reportados por [Gallo et al., (2017)](https://www.zotero.org/google-docs/?D6DOeE) quienes, en experimentos de micropropagación de clones de *E. grandis × E. urophylla* y *E. urophylla × E. globulus*, documentaron valores más bajos de peso seco de raíces a medida que se incrementó la dosis de AIB aplicada.

Una posible explicación para estas diferencias radica en el efecto de las auxinas, como el AIB, que promueven la división y elongación celular, esenciales para el desarrollo radicular. No obstante, concentraciones muy bajas pueden ser insuficientes para inducir un enraizamiento efectivo, mientras que dosis excesivas generan fitotoxicidad, afectando la formación y crecimiento de las raíces, lo que se traduce en una reducción del peso seco. Adicionalmente, concentraciones elevadas de AIB pueden desencadenar interacciones negativas con otros reguladores internos, como las citocininas, alterando el balance hormonal requerido para la rizogénesis. Este desequilibrio puede inhibir la elongación y diferenciación celular en las raíces [(Druege et al., 2019)](https://www.zotero.org/google-docs/?5kCdue). 

Los hallazgos de este estudio resaltan la importancia de seleccionar una concentración adecuada de AIB para optimizar la inducción radicular, evitando al mismo tiempo efectos fitotóxicos. El tratamiento comercial (4000 ppm de ANA + 1000 ppm de AIB) mostró la mayor eficiencia, lo que refuerza su potencial para mejorar la propagación vegetativa de *Eucalyptus grandis × E. urophylla* en programas de reforestación comercial en la selva central del Perú. Los resultados también ponen en evidencia las complejas interacciones entre las concentraciones de auxinas, la genética de la planta y las condiciones ambientales, lo que indica la necesidad de realizar estudios adicionales que profundicen en estas variables para perfeccionar las técnicas de propagación clonal.

# **CONCLUSIONES**

La aplicación de ácido indol-3-butírico (AIB) tuvo un impacto significativo en el enraizamiento de las estaquillas de E. *grandis × E. urophylla*. Los tratamientos de 1 500 ppm de AIB y el preparado comercial (4 000 ppm ANA + 1 000 ppm AIB) se destacaron como los más efectivos, logrando mayores porcentajes de enraizamiento, menor mortalidad y mejores resultados en la longitud y peso seco de raíces. Sin embargo,  no se encontraron diferencias significativas en la cantidad de raíces formadas entre los tratamientos evaluados. En general, el preparado comercial demostró ser el tratamiento más eficiente, evidenciando su potencial para optimizar la propagación vegetativa de esta especie en la Selva Central del Perú.

# **REFERENCIAS**

[Abedini, W. (2005). Propagación vegetativa de *Parkinsonia aculeata* L. por estaquillado. *Quebracho - Revista de Ciencias Forestales*, *12*, 23-33.](https://www.zotero.org/google-docs/?uviWq0)

[Alcantara-Cortes, J. S., Acero Godoy, J., Alcántara Cortés, J. D., & Sánchez Mora, R. M. (2019). Principales reguladores hormonales y sus interacciones en el crecimiento vegetal. *Nova*, *17*(32), 109-129.](https://www.zotero.org/google-docs/?uviWq0)

[Ayala, P., Surenciski, M., Harrand, L., & Luna, C. (2020). Capacidad de enraizamiento de clones híbridos de *Eucalyptus* del Instituto Nacional de Tecnología Agropecuaria, Argentina. *Temas Agrarios*, *25*(1), Article 1. https://doi.org/10.21897/rta.v25i1.2214](https://www.zotero.org/google-docs/?uviWq0)

[Basauri Torres, Y., Guerra Arévalo, W., Gorbitz Dupuy, G., Lombardi Indacochea, I., Guerra Arévalo, H., Oliveira, E. M. de, Monteiro Neto, J. L. L., Del Castillo Torres, D., Rojas Mego, K., & Abanto Rodríguez, C. (2019). Enraizamiento de miniestacas de *Guazuma crinita* M. utilizando diferentes invernaderos, sustratos y aditivos. *Instituto de Investigaciones de la Amazonia Peruana*. https://doi.org/10.18671/scifor.v47n124.05](https://www.zotero.org/google-docs/?uviWq0)

[Bautista-Ojeda, G. I., Vargas-Hernández, J. J., Jiménez-Casas, M., & López-Peralta, M. C. G. (2022). Manejo de planta y aplicación de AIB en el enraizado de estacas de *Pinus patula*. *Madera y bosques*, *28*(1). https://doi.org/10.21829/myb.2022.2812060](https://www.zotero.org/google-docs/?uviWq0)

[Borges, S. R., Xavier, A., Oliveira, L. S. de, Melo, L. A. de, & Rosado, A. M. (2011). Enraizamento de miniestacas de clones híbridos de *Eucalyptus globulus*. *Revista Árvore*, *35*, 425-434. https://doi.org/10.1590/S0100-67622011000300006](https://www.zotero.org/google-docs/?uviWq0)

[Brondani, G. E., Grossi, F., Wendling, I., Dutra, L. F., & Araujo, M. A. de. (2010). Aplicação de IBA para o enraizamento de miniestacas de *Eucalyptus benthamii* Maiden & Cambage x *Eucalyptus dunnii* Maiden. *Acta Scientiarum. Agronomy*, *32*(4), Article 4. https://doi.org/10.4025/actasciagron.v32i4.4879](https://www.zotero.org/google-docs/?uviWq0)

[Bueno, P., Xavier, A., & Zeferino, N. (2008). Efeito dos reguladores de crescimento AIB e ANA no enraizamento de miniestacas de clones de *Eucalyptus grandis x Eucalyptus urophylla*. *Revista Árvore*, *32*, 1051-1058. https://doi.org/10.1590/S0100-67622008000600010](https://www.zotero.org/google-docs/?uviWq0)

[Cachique, D., Castillo, Á. M. R.-D., Ruíz-Solsol, H., Vallejos, G., & Solis, R. (2011). Propagación vegetativa del Sacha Inchi (*Plukenetia volubilis* L.) mediante enraizamiento de estacas juveniles en cámaras de subirrigación en la amazonia peruana. *Folia Amazónica*, *20*(1-2), Article 1-2. https://doi.org/10.24841/fa.v20i1-2.348](https://www.zotero.org/google-docs/?uviWq0)

[Canchari, N. N. U., Baral, P., & Wang, L. (2018). Local Contributions of Forests to Economic Growth of Peru: A Case of Plantations. *ECONOMICS*, *6*(1), 17-31. https://doi.org/10.2478/eoik-2018-0001](https://www.zotero.org/google-docs/?uviWq0)

[Carranza Patiño, M. S., Roca Moreno, S. L. R., Morante Carriel, J. A., & López Tobar, R. M. (2022). Propagation of juvenile cuttings of clones of (tropical *Eucalyptus*) Eucalyptus urugrandis: Examination of the role of auxins in adventitious rooting. *Journal of Pharmaceutical Negative Results*, *13*(3), 427-432. https://doi.org/10.47750/pnr.2022.13.03.065](https://www.zotero.org/google-docs/?uviWq0)

[De Almeida, M. R., Aumond, M., Da Costa, C. T., Schwambach, J., Ruedell, C. M., Correa, L. R., & Fett-Neto, A. G. (2017). Environmental control of adventitious rooting in *Eucalyptus and Populus* cuttings. *Trees*, *31*(5), 1377-1390. https://doi.org/10.1007/s00468-017-1550-6](https://www.zotero.org/google-docs/?uviWq0)

[Druege, U., Hilo, A., Pérez-Pérez, J. M., Klopotek, Y., Acosta, M., Shahinnia, F., Zerche, S., Franken, P., & Hajirezaei, M. R. (2019). Molecular and physiological control of adventitious rooting in cuttings: Phytohormone action meets resource allocation. *Annals of Botany*, *123*(6), 929-949. https://doi.org/10.1093/aob/mcy234](https://www.zotero.org/google-docs/?uviWq0)

[FAO. (2021). *Evaluación de los recursos forestales mundiales 2020*. FAO ; https://openknowledge.fao.org/handle/20.500.14283/ca9825es](https://www.zotero.org/google-docs/?uviWq0)

[Felice, F. E. F. de, Dias-Araujo, P. C., Pinheiro, E. S., & Vergara, C. (2024). Mini-cutting technique for the propagation of a *Eucalyptus camaldulensis* clone selected in a semiarid region. *Forest Systems*, *33*(3), Article 3. https://doi.org/10.5424/fs/2024333-20905](https://www.zotero.org/google-docs/?uviWq0)

[Gallo, R., Xavier, A., Moura, L. C. de, Oliveira, B. de A., Nascimento, H. R. do, & Otoni, W. C. (2017). IBA and microcutting collections in the micropropagation of *Eucalyptus spp*  hybrid clones. *Revista Árvore*, *41*, e410605. https://doi.org/10.1590/1806-90882017000600005](https://www.zotero.org/google-docs/?uviWq0)

[Gorbitz, G. E., Ríos, L., Marujo, C., Cornejo, V., Medina, R., & Sáenz, L. (2020). Estimación de la ganancia genética esperada de *Pinus tecunumanii* en plantaciones forestales en Oxapampa, Perú. *Revista Forestal del Perú*, *35*(3), Article 3. https://doi.org/10.21704/rfp.v35i3.1601](https://www.zotero.org/google-docs/?uviWq0)

[Guariguata, M. R., Arce, J., Ammour, T., & Capella, J. L. (2017). *Las plantaciones forestales en Perú: Reflexiones, estatus actual y perspectivas a futuro*. https://doi.org/10.17528/cifor/006461](https://www.zotero.org/google-docs/?uviWq0)

[Husson, F., Josse, J., Le, S., & Mazet, J. (2024). *FactoMineR: Multivariate Exploratory Data Analysis and Data Mining*. https://doi.org/10.32614/CRAN.package.FactoMineR](https://www.zotero.org/google-docs/?uviWq0)

[Lopes, A. D. S., Tsukamoto Filho, A. D. A., Brondani, G. E., Kratz, D., Silva, D. D., Matos, S. E. D., & Oliveira, T. M. D. (2019). Efeitos da nutrição mineral, coleta de brotações e ácido indolbutírico (AIB) no enraizamento e histologia de miniestacas de *Eucalyptus urophylla* S. T. Blake. *Scientia Forestalis*, *47*(123). https://doi.org/10.18671/scifor.v47n123.10](https://www.zotero.org/google-docs/?uviWq0)

[Machacuay, A., & Llancari, Y. M. (2020). Efecto de dosis de nitrógeno sobre la producción de estaquillas de *Eucalyptus grandis × E. urophylla* en jardín clonal. *Revista Forestal del Perú*, *35*(3), Article 3. https://doi.org/10.21704/rfp.v35i3.1597](https://www.zotero.org/google-docs/?uviWq0)

[Mendiburu, F. de. (2023). *agricolae: Statistical Procedures for Agricultural Research*. https://doi.org/10.32614/CRAN.package.agricolae](https://www.zotero.org/google-docs/?uviWq0)

[More, P., Cuellar, J., & Salazar, E. (2021). Propagación vegetativa de *Retrophyllum rospigliosii* (Pilg.) C.N. Page "ulcumano" en cámara de subirrigación en Chanchamayo / Perú. *Ecología Aplicada*, *20*(1), Article 1. https://doi.org/10.21704/rea.v20i1.1687](https://www.zotero.org/google-docs/?uviWq0)

[Muñoz, L. I. (2018). *Evaluación de la eficiencia del ácido indolbutírico (AIB) en el enraizamiento de mini estacas de *Eucalyptus urophylla x grandis *(Eucalipto urograndis), cantón Buena Fe, provincia Los Ríos.* [bachelorThesis, Escuela Superior Politécnica de Chimborazo]. http://dspace.espoch.edu.ec/handle/123456789/10362*​*​](https://www.zotero.org/google-docs/?uviWq0)

[Navarrete-Luna, M., & Vargas-Hernández, J. (2005). Propagación asexual de clones de *Eucalyptus camaldulensis* Dehnh. Utilizando radix en diferentes concentraciones. *Revista Chapingo. Serie Ciencias Forestales y del Ambiente*, *11*(2), 111-116.](https://www.zotero.org/google-docs/?uviWq0)

[Nourissier, S., & Monteuuis, O. (2008). In vitro rooting of two *Eucalyptus urophylla X Eucalyptus grandis* mature clones. *In Vitro Cellular & Developmental Biology - Plant*, *44*(4), 263-272. https://doi.org/10.1007/s11627-008-9109-2](https://www.zotero.org/google-docs/?uviWq0)

[Oliva-Cruz, C. A., Vargas-Paredes, V. H., & Linares-Bensimón, C. (2005). Selección de plantas madre promisorias de *Myrciaria dubia* (HBK) Mc Vaugh, Camu Camu arbustivo, en Ucayali-Perú. *Folia Amazónica*, *14*(2), Article 2. https://doi.org/10.24841/fa.v14i2.407](https://www.zotero.org/google-docs/?uviWq0)

[Osuri, A. M., Gopal, A., Raman, T. R. S., DeFries, R., Cook-Patton, S. C., & Naeem, S. (2020). Greater stability of carbon capture in species-rich natural forests compared to species-poor plantations. *Environmental Research Letters*, *15*(3), 034011. https://doi.org/10.1088/1748-9326/ab5f75](https://www.zotero.org/google-docs/?uviWq0)

[Peña-Baracaldo, F. J., Chaparro-Zambrano, H. N., Sierra, A., Rodríguez, J., Cabezas-Gutiérrez, M., Peña-Baracaldo, F. J., Chaparro-Zambrano, H. N., Sierra, A., Rodríguez, J., & Cabezas-Gutiérrez, M. (2018). Effect of different substrates and auxins on rooting of *Leucadendron sp.* (Proteaceae). *Revista U.D.C.A Actualidad &amp; Divulgación Científica*, *21*(2), 385-393. https://doi.org/10.31910/rudca.v21.n2.2018.968](https://www.zotero.org/google-docs/?uviWq0)

[Pirard, R., Dal Secco, L., & Warman, R. (2016). Do timber plantations contribute to forest conservation? *Environmental Science & Policy*, *57*, 122-130. https://doi.org/10.1016/j.envsci.2015.12.010](https://www.zotero.org/google-docs/?uviWq0)

[R Core Team. (2024). *R: A Language and Environment for Statistical Computing* (Versión 4.4.2) [Software]. R Foundation for Statistical Computing. https://www.r-project.org/](https://www.zotero.org/google-docs/?uviWq0)

[Rivera Melo, F., Jiménez Casas, M., Ramírez Herrera, C., & Martínez Rendón, A. Y. (2021). Enraizamiento de estacas de *Pinus hartwegii* de tres poblaciones naturales en ecosistemas de alta montaña del Estado de México y Veracruz. *Bosque (Valdivia)*, *42*(3), 323-331. https://doi.org/10.4067/S0717-92002021000300323](https://www.zotero.org/google-docs/?uviWq0)

[Schielzeth, H., Dingemanse, N. J., Nakagawa, S., Westneat, D. F., Allegue, H., Teplitsky, C., Réale, D., Dochtermann, N. A., Garamszegi, L. Z., & Araya-Ajoy, Y. G. (2020). Robustness of linear mixed-effects models to violations of distributional assumptions. *Methods in Ecology and Evolution*, *11*(9), 1141-1152. https://doi.org/10.1111/2041-210X.13434](https://www.zotero.org/google-docs/?uviWq0)

[Servicio Nacional de Meteorología e Hidrología del Perú, S. (2024). *Datos Hidrometeorológicos en Junín*. https://www.senamhi.gob.pe/main.php?dp=junin&p=estaciones](https://www.zotero.org/google-docs/?uviWq0)

[Servicio Nacional Forestal y de Fauna Silvestre. (2015). *Ley Forestal y de Fauna Silvestre N° 29763 y sus Reglamentos*. Servicio Nacional Forestal y de Fauna Silvestre. https://repositorio.serfor.gob.pe/handle/SERFOR/620](https://www.zotero.org/google-docs/?uviWq0)

[Servicio Nacional Forestal y Fauna Silvestre. (2021). *Estrategia para la Promoción de Plantaciones Forestales Comerciales 2021 -2050* (1; p. 114). Servicio Nacional Forestal y Fauna Silvestre. https://cdn.www.gob.pe/uploads/document/file/2244409/EPPFC-28\_09\_2021-Revision\_OGAJ\_04\_10\_2021FF.pdf.pdf](https://www.zotero.org/google-docs/?uviWq0)

[Silva, L. N., Freer-Smith, P., & Madsen, P. (2019). Production, restoration, mitigation: A new generation of plantations. *New Forests*, *50*(2), 153-168. https://doi.org/10.1007/s11056-018-9644-6](https://www.zotero.org/google-docs/?uviWq0)

[Swarts, A., Matsiliza-Mlathi, B., & Kleynhans, R. (2018). Rooting and survival of *Lobostemon fruticosus* (L) H. Buek stem cuttings as affected by season, media and cutting position. *South African Journal of Botany*, *119*, 80-85. https://doi.org/10.1016/j.sajb.2018.08.019](https://www.zotero.org/google-docs/?uviWq0)

[Titon, M., Xavier, A., Otoni, W. C., & Reis, G. G. dos. (2003). Efeito do AIB no enraizamento de miniestacas e microestacas de clones de Eucalyptus grandis W. Hill ex Maiden. *Revista Árvore*, *27*, 1-7. https://doi.org/10.1590/S0100-67622003000100001](https://www.zotero.org/google-docs/?uviWq0)

[Vásquez Inuma, L. L., Ayala Montejo, D., Vallejos Torres, G., Arévalo López, L. A., Bustamante Ochoa, C., Calixto Vásquez, E., & Ramos Vásquez, E. (2018). Edad del material vegetativo y su efecto en el enraizamiento de brotes de café (*Coffea arabica*) variedad caturra. *Investigación Valdizana*, *12*(4), Article 4. https://doi.org/10.33554/riv.12.4.157](https://www.zotero.org/google-docs/?uviWq0)

[Vilasboa, J., Da Costa, C. T., & Fett-Neto, A. G. (2019). Rooting of eucalypt cuttings as a problem-solving oriented model in plant biology. *Progress in Biophysics and Molecular Biology*, *146*, 85-97. https://doi.org/10.1016/j.pbiomolbio.2018.12.007](https://www.zotero.org/google-docs/?uviWq0)

[Zeng, Y., Wu, H., Ouyang, S., Chen, L., Fang, X., Peng, C., Liu, S., Xiao, W., & Xiang, W. (2021). Ecosystem service multifunctionality of Chinese fir plantations differing in stand age and implications for sustainable management. *Science of The Total Environment*, *788*, 147791. https://doi.org/10.1016/j.scitotenv.2021.147791](https://www.zotero.org/google-docs/?uviWq0)